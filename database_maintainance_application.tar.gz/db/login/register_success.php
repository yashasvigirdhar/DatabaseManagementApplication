<?php
echo "<script type='text/javascript'>alert('hello');</script>";
echo 'you have been successfully registered :D';
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
