<?php
session_start();
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
	// echo "welcome"
} else {
    header('Location: access.php');
}
?>


<?php
require 'connect.inc.php';

$sql="SELECT * FROM MENU";

$result = mysql_query($sql);

echo "<table border='1'>
<tr>
<th>Item No</th>
<th>Price</th>
<th>Category</th>
<th>Name</th>
</tr>";

while($row = mysql_fetch_array($result))
  {
  echo "<tr>";
  echo "<td>" . $row['ITEM_NO'] . "</td>";
  echo "<td>" . $row['PRICE'] . "</td>";
  echo "<td>" . $row['CATEGORY'] . "</td>";
  echo "<td>" . $row['NAME'] . "</td>";
  echo "</tr>";
  }
echo "</table>";


?>

