<link href="./../style.css" rel="stylesheet" type="text/css" media="screen" />
<br><h2>Please log in first to see this page.</h2>
<a href="login.inc.php">Login</a>
