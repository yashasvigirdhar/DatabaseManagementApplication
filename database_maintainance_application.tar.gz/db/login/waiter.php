<?php
session_start();
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
	// echo "welcome"
} else {
    header('Location: access.php');
}
?>

<?php
$flag=$_GET['flag'];
if($flag==1){
    echo "<script type='text/javascript'>alert('You have successfuly registered.');</script>";
}
echo "Hello ".$_GET['name'];
echo "<br>Hello ".$_GET['ssn'];
echo "<br><br>This is waiter page";

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>

<head>
<script>
function loadXMLDoc()
{
var xmlhttp;
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
	//alert("hello");
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("myDiv").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET","getorderdata.php",true);
xmlhttp.send();
}
</script>
</head>

<Body>
    <h3>Customer Order</h3>
<input type="button" onclick="loadXMLDoc()" value="Show Customer orders" /><br><br>
<div id="myDiv"><h2></h2></div>
<a href="logout.php">Logout</a>
</body>
