<form action="table.php" method="POST">
No of columns:<input type="text" name="no">
<input type="submit" value="proceed">
</button>
